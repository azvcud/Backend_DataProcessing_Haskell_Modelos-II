# Revision history for Backend-DataProcessing-Haskell-Modelos-II

## 0.1.0.0 -- YYYY-mm-dd

* First version. Released on an unsuspecting world.
